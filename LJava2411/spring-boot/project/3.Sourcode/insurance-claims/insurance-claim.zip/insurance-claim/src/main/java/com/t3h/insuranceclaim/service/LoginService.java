package com.t3h.insuranceclaim.service;

import org.springframework.ui.Model;

public interface LoginService {

}
