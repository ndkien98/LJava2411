package vn.com.t3h.service;

public interface FileService {

    String getBase64FromPath(String path);
}
