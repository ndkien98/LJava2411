package vn.com.t3h.service;

public interface LoginService {

    public String processAfterLoginSuccess();
}
