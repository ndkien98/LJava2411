package vn.com.t3h.utils;

public class Constant {

    public static String ROLE_ADMIN_CODE="ADMIN";
    public static final String CODE_START="C";

    public static String PREFIX_ROLE="ROLE_";

    public static final String CACHE_JWT="JWT_CACHE";
}
